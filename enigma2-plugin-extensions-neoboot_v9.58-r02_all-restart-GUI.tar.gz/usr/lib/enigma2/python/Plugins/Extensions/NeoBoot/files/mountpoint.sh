#!/bin/sh

umount -l /media/hdd
mkdir -p /media/hdd
mkdir -p /media/sda1
/bin/mount /dev/sda1 /media/hdd
/bin/mount /dev/sda1 /media/sda1


exit 0
