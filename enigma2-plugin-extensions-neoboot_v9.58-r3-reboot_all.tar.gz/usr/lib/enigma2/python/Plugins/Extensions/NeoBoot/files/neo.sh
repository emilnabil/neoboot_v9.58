#!/bin/sh

/bin/mount /dev/sda1 /media/hdd/  

exit 0